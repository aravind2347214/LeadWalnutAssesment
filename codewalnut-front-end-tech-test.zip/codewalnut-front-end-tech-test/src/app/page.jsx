'use client'

import React, { useEffect, useState } from 'react';

export default function Home() {
  const ITEMS_PER_PAGE = 12;

  const [pokemon, setPokemon] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [selectedPokemon, setSelectedPokemon] = useState(null);
  const [typeFilter, setTypeFilter] = useState('all');

  useEffect(() => {
    fetchPokemonList((currentPage - 1) * ITEMS_PER_PAGE);
  }, [currentPage]);

  const fetchPokemonList = async (offset) => {
    setLoading(true);
    try {
      const response = await fetch(`https://pokeapi.co/api/v2/pokemon?limit=${ITEMS_PER_PAGE}&offset=${offset}`);
      const data = await response.json();
      setTotalPages(Math.ceil(data.count / ITEMS_PER_PAGE));
      
      const detailedPokemon = await Promise.all(
        data.results.map(async (pokemon) => {
          const res = await fetch(pokemon.url);
          return res.json();
        })
      );
      
      setPokemon(detailedPokemon);
    } catch (err) {
      setError('Failed to fetch Pokémon list. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

 

  const fetchPokemonDetails = async (id) => {
    try {
      const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${id}`);
      const data = await response.json();
      setSelectedPokemon(data);
    } catch (err) {
      setError('Failed to fetch Pokémon details.');
    }
  };

  const filteredPokemon = pokemon.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === 'all' || p.types.some(t => t.type.name === typeFilter);
    return matchesSearch && matchesType;
  });

  const PokemonCard = ({ pokemon }) => (
    <div 
      className="transition-all duration-200 bg-white border-2 border-gray-300 rounded-lg shadow-md cursor-pointer hover:shadow-lg hover:scale-105"
      onClick={() => fetchPokemonDetails(pokemon.id)}
    >
      <div className="flex flex-col items-center p-4">
        <img
          src={pokemon.sprites.front_default}
          alt={pokemon.name}
          className="w-32 h-32 mb-2"
        />
        <h2 className="mb-2 text-lg font-bold capitalize">{pokemon.name}</h2>
        <div className="flex gap-1">
          {pokemon.types.map(({ type }) => (
            <span
              key={type.name}
              className="px-2 py-1 text-sm font-semibold text-gray-800 bg-gray-200 rounded"
            >
              {type.name}
            </span>
          ))}
        </div>
      </div>
    </div>
  );



  return (
    <div className="container px-5 py-8 mx-auto lg:px-32 xl:p-44">
      <h1 className="mb-8 text-4xl font-bold text-center md:text-5xl xl:text-6xl">Pokémon Explorer</h1>
      
      <div className="flex flex-col gap-4 mb-8 md:flex-row">
        <input
          type="text"
          placeholder="Search Pokémon..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="px-4 py-2 border-2 border-gray-300 rounded-lg flex-grow focus:outline-none w-full md:w-[400px]"
        />
        
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="px-4 py-2 border-2 border-gray-300 rounded-lg focus:outline-none"
        >
          <option value="all">All Types</option>
          <option value="fire">Fire</option>
          <option value="water">Water</option>
          <option value="grass">Grass</option>
          <option value="electric">Electric</option>
        </select>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <Loader/>
        </div>
      ) : error ? (
        <div className="text-center text-red-500">{error}</div>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {filteredPokemon.map(pokemon => (
              <PokemonCard key={pokemon.id} pokemon={pokemon} />
            ))}
          </div>
          
          <div className="flex justify-center mt-8">
            <div className="flex items-center gap-2">
              <button
              type = "button"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="p-2 rounded-full hover:bg-gray-200 disabled:opacity-50"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              
              <span className="mx-4">
                Page {currentPage} of {totalPages}
              </span>
              
              <button
               type="button"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="p-2 rounded-full hover:bg-gray-200 disabled:opacity-50"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>
          </div>
        </>
      )}

      {selectedPokemon && (
        <PokemonModal 
          pokemon={selectedPokemon} 
          onClose={() => setSelectedPokemon(null)} 
        />
      )}
    </div>
  );
}

const Loader = () => 
  ( 
    <div className="loader">
      <div className="bar1"/>
      <div className="bar2"/>
      <div className="bar3"/>
      <div className="bar4"/>
      <div className="bar5"/>
      <div className="bar6"/>
      <div className="bar7"/>
      <div className="bar8"/>
      <div className="bar9"/>
      <div className="bar10"/>
      <div className="bar11"/>
      <div className="bar12"/>
    </div>
  );


  const PokemonModal = ({ pokemon, onClose }) => {
    if (!pokemon) return null;
    
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50">
        <div className="bg-white rounded-lg p-6 max-w-md w-full relative max-h-[95vh] overflow-y-auto">
          <button 
           type="button"
            onClick={onClose}
            className="absolute text-gray-500 top-4 right-4 hover:text-gray-700"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
          <div className="flex flex-col items-center">
            <img
              src={pokemon.sprites.front_default}
              alt={pokemon.name}
              className="w-40 h-40 mb-4"
            />
            <h2 className="mb-4 text-2xl font-bold capitalize">{pokemon.name}</h2>
            
            <div className="w-full mb-4 p-3 bg-gray-100 rounded-[4px]">
              <h3 className="mb-2 font-bold">Stats:</h3>
              {pokemon.stats.map(stat => (
                <div key={stat.stat.name} className="mb-2">
                  <div className="flex justify-between mb-1">
                    <span className="capitalize">{stat.stat.name}</span>
                    <span>{stat.base_stat}</span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 rounded-full">
                    <div 
                      className="h-2 bg-gray-600 rounded-full"
                      style={{ width: `${(stat.base_stat / 255) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
            
            <div className="w-full">
              <h3 className="mb-2 font-bold">Abilities:</h3>
              <div className="flex flex-wrap gap-2">
                {pokemon.abilities.map(({ ability }) => (
                  <span 
                    key={ability.name}
                    className="px-3 py-1 bg-gray-200 rounded-[4px] text-sm capitalize"
                  >
                    {ability.name}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };
